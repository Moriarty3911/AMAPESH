package com.example.amapesh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }


    public void CambiarA(View view){
        Intent i = new Intent(this, A.class);
        startActivity(i);
    }

    public void CambiarB(View view){
        Intent i = new Intent(this, B.class);
        startActivity(i);
    }

    public void CambiarC(View view){
        Intent i = new Intent(this, C.class);
        startActivity(i);
    }

    public void CambiarD(View view){
        Intent i = new Intent(this, D.class);
        startActivity(i);
    }

    public void CambiarE(View view){
        Intent i = new Intent(this, E.class);
        startActivity(i);
    }


    public void Cambio(View view){
        Intent i = new Intent(this,E.class);
        startActivity(i);
    }
}
